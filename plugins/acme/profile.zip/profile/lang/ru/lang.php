<?php return [
    'plugin' => [
        'name' => 'Profile',
        'description' => ''
    ]
];